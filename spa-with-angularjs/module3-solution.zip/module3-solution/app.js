(function(){
  'use strict';

  angular.module('NarrowItDownApp', [])
  //.controller('NarrowItDownController', NarrowItDownController)
  //.service('MenuSearchService', MenuSearchService)
  //.constant('ApiBasePath',"https://davids-restaurant.herokuapp.com");

  //NarrowItDownController.$inject = ['MenuSearchService'];
  function NarrowItDownController(MenuSearchService){
    // var narrowItCtrl = this;
    // narrowItCtrl.searchTerm = 'chicken';
    //  MenuSearchService.getMatchedMenuItems(searchTerm).then(
    //    function(response){
    //      narrowItCtrl.items = response;
    //    }
    //  );
    //
    //  console.log(narrowItCtrl.items);

  }

//  MenuSearchService.$inject = ['$http', '$q', 'ApiBasePath'];
//  function MenuSearchService($http, $q, ApiBasePath) {
    // var menuSvc = this;
    // menuSvc.getMatchedMenuItems = function(searchTerm){
    //     var deferred = $q.defer();
    //     $http.get(ApiBasePath + '/menu_items.json').then(function(result){
    //       var foundItems = [];
    //       var data = result.data;
    //       if (!data){
    //         deferred.reject("");
    //       }else{
    //         for (var i = 0; i < data.length; i++) {
    //             var description = data[i].description;
    //             if (description.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1) {
    //                 foundItems.push(data[i]);
    //             }
    //         }
    //           deferred.resolve(foundItems);
    //       }
    //   }, function(result){
    //       deferred.reject("");
    //   });
    //   return deferred.promise;
    // }

//  }

})()
